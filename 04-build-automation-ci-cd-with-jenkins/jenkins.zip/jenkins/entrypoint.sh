#!/bin/bash
# Runs as the JENKINS user (thanks to `USER jenkins` in the Dockerfile).
# That's also what makes `docker exec -it jenkins bash` land as jenkins
# without any `-u jenkins` flag.
set -e

# Briefly escalate via sudo to align the in-container docker group with
# the host's /var/run/docker.sock GID. The sudoers rule allows ONLY this
# one script to run as root — jenkins can't sudo anything else.
sudo /usr/local/bin/fix-docker-gid.sh

# Re-exec as jenkins so the process picks up the new group membership.
# `usermod -aG` updates /etc/group on disk, but it doesn't refresh the
# credentials of an already-running process. `sudo -u` calls initgroups()
# when it launches the child, which re-reads /etc/group and gives the
# new process fresh supplementary groups. A plain `exec "$@"` here would
# inherit the stale groups and `docker ps` would still fail.
# `-E` preserves environment variables Jenkins depends on (JAVA_OPTS,
# JENKINS_HOME, PATH, etc.) — allowed by the SETENV tag in sudoers.
exec sudo -E -u jenkins -- "$@"
