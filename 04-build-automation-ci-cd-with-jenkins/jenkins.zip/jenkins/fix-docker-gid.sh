#!/bin/bash
# Runs as ROOT (via `sudo /usr/local/bin/fix-docker-gid.sh` from the
# entrypoint). The sudoers rule only allows this one script to run as
# root — nothing else — so the escalation path is narrow and auditable.
#
# Its job: make sure a group with the same GID as the host's docker
# socket exists inside the container, and that the jenkins user belongs
# to it. Without this, the jenkins user can't access /var/run/docker.sock.
set -e

# Defense-in-depth: pin PATH to a known-good set so command resolution
# inside this root-targeted script can't be influenced by the caller's
# environment. Only affects this script's process — the entrypoint's
# PATH (which includes /opt/java/openjdk/bin) is unchanged.
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

SOCKET=/var/run/docker.sock

# Skip silently if the socket wasn't bind-mounted. Jenkins can still
# start in this case — it just won't be able to run docker commands.
if [ -S "$SOCKET" ]; then
    # The kernel enforces permissions on the bind-mounted socket by
    # NUMERIC GID, not by group name. We read the actual GID from the
    # mounted socket — that's the number jenkins needs to belong to.
    SOCKET_GID=$(stat -c '%g' "$SOCKET")

    # Check whether any group inside the container already owns that GID.
    # `getent` exits non-zero when no match is found; `|| true` keeps
    # `set -e` from killing the script in that case.
    GROUP=$(getent group "$SOCKET_GID" | cut -d: -f1 || true)

    # If no group currently owns the socket's GID, create one. The name
    # is arbitrary — permissions only care about the numeric GID — so
    # we pick a descriptive placeholder.
    if [ -z "$GROUP" ]; then
        GROUP=docker-host
        groupadd -g "$SOCKET_GID" "$GROUP"
    fi

    # Add jenkins to that group. `usermod -aG` is idempotent, so re-
    # running this on container restart is safe.
    usermod -aG "$GROUP" jenkins
fi
